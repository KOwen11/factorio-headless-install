This script intended for default AWS ec2 server running ubuntu 16.04 with default user [ubuntu]

1a. create /home/ubuntu if not using default user [ubuntu]
1b. alternatively modify factorio.service with your ~/ home directory
2. extract contents of FactorioHeadlessInstaller.zip
3. run install.sh

This will finish by creating a save file and starting the server using default settings 
